package sentiprofiler.ui.tagcloud;

import java.util.List;

public interface TagCloud {
    public List<TagCloudElement> getTagCloudElements();
}
