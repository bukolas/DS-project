package sentiprofiler.ui.tagcloud;

public interface VisualizeTagCloudDecorator {
    public String decorateTagCloud(TagCloud tagCloud);
}
